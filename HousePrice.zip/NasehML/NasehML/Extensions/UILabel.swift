//
//  UILabled.swift
//  CopyResan
//
//  Created by ali on 11/12/18.
//  Copyright © 2018 pencode. All rights reserved.
//

import Foundation
import UIKit

extension UILabel {
    convenience init(text : String, size : CGFloat?, color : UIColor? , textAlignment : NSTextAlignment,backgroundColor : UIColor? = .clear) {
        self.init()
        self.text = text
        self.textColor = color
        self.textAlignment = textAlignment
        self.numberOfLines = 0
        self.minimumScaleFactor = 0.5
        self.adjustsFontSizeToFitWidth = true
        self.lineBreakMode = .byWordWrapping
        
        self.backgroundColor = backgroundColor
        self.addObserver(self, forKeyPath: "text", options: [.new, .old], context: nil)
        sizeToFit()
    }
    
    open override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        removeObserver(self, forKeyPath: "text")
        
        self.addObserver(self, forKeyPath: "text", options: [.new, .old], context: nil)
    }
    
    
    
    convenience init(icon : String, size : CGFloat?, color : UIColor?) {
        self.init()
        self.text = icon
        self.textAlignment = .center
        self.textColor = color
        
        sizeToFit()
    }
}
