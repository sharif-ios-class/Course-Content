//
//  UIButton.swift
//  CopyResan
//
//  Created by ali on 11/13/18.
//  Copyright © 2018 pencode. All rights reserved.
//

import Foundation
import UIKit

extension UIButton {
    
    convenience init(title :String,
                     titleSize: CGFloat? ,
                     titleColor: UIColor? ,
                     backgroundColor: UIColor? ,
                     cornerRadius: CGFloat? ,
                     borderWidth : CGFloat? ,
                     borderColor : UIColor?
        ){
        self.init()
        
        self.setTitle(title, for: .normal)
        self.setTitle(title, for: .application)
        self.setTitleColor(titleColor!, for: .normal)
        self.setTitleColor(titleColor!.withAlphaComponent(0.5), for: .highlighted)
        self.backgroundColor = backgroundColor
        self.layer.cornerRadius = cornerRadius!
        layer.borderWidth = borderWidth!
        layer.borderColor = borderColor!.cgColor
    }
    
    convenience init(icon : String,
                     size : CGFloat? = 15,
                     color : UIColor? = UIColor.white,
                     backgroundColor: UIColor? ,
                     cornerRadius: CGFloat? ,
                     borderWidth : CGFloat? ,
                     borderColor : UIColor?
        ) {
        self.init()
        self.setTitle(icon, for: .normal)
        self.setTitle(icon, for: .application)
        self.titleLabel?.textAlignment = .center
        self.setTitleColor(color!, for: .normal)
        self.setTitleColor(color!.withAlphaComponent(0.5), for: .highlighted)
        
        self.backgroundColor = backgroundColor
        self.layer.cornerRadius = cornerRadius!
        layer.borderWidth = borderWidth!
        layer.borderColor = (borderColor ?? UIColor.black).cgColor
    }
   
}
