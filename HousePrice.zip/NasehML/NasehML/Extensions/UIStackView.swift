//
//  UIStackView.swift
//  CopyResan
//
//  Created by ali on 11/11/18.
//  Copyright © 2018 pencode. All rights reserved.
//

import Foundation
import UIKit

extension UIStackView {
    convenience init(distribution: UIStackView.Distribution, axis: NSLayoutConstraint.Axis? = .vertical, spacing: CGFloat? = 20, views: [UIView]? = []){
        self.init()
        self.axis = axis!
        self.spacing = spacing!
        self.distribution = distribution
        if let vs = views {
            for v in vs {
                self.addArrangedSubview(v)
            }
        }
    }
    
    func addArrangedSubviews(_ views : [UIView]){
        for v in views {
            addArrangedSubview(v)
        }
    }
}
