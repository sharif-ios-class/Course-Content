//
//  UITextField.swift
//  CopyResan
//
//  Created by ali on 11/13/18.
//  Copyright © 2018 pencode. All rights reserved.
//

import Foundation
import UIKit

extension UITextField{
    convenience init(placeholder : String,
                     icon : String? = nil,
                     textSize : CGFloat?,
                     textColor : UIColor? = .black,
                     backgroundColor : UIColor? = .white,
                     cornerRadius : CGFloat? ,
                     borderWidth : CGFloat? = 1 ,
                     borderColor : UIColor?,
                     keyboardType : UIKeyboardType? = .default
        ){
        self.init()
        self.placeholder = placeholder
        textAlignment = .left
        if cornerRadius! > 0 {
            layer.cornerRadius = cornerRadius!
        }
        self.backgroundColor = backgroundColor!
        if borderWidth! > 0 {
            layer.borderWidth = borderWidth!
            layer.borderColor = borderColor!.cgColor
        }
        //self.semanticContentAttribute = .forceRightToLeft
        if let i = icon {
            let label = UILabel(icon: i, size: textSize, color: textColor!)
            addSubview(label)
            label.snp.makeConstraints { (v) in
                v.top.equalToSuperview()
                v.bottom.equalToSuperview()
                v.right.equalToSuperview()
                v.width.equalTo(30)
            }
            self.rightView = label
            self.rightViewMode = .always
        }
        self.keyboardType = keyboardType!
        self.clearButtonMode = .whileEditing
        self.rightViewMode = .always
        self.leftViewMode = .always
        self.addObserver(self, forKeyPath: "text", options: [.new, .old], context: nil)
        //addToolBar()

    }
    
    
    struct Holder {
        static var callback: (() -> ())? = nil
    }
    
    var callback: (() -> ())? {
        get {
            return Holder.callback
        }
        set(newValue) {
            Holder.callback = newValue
        }
    }
    
    open override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        removeObserver(self, forKeyPath: "text")
        
        if let c = callback {
            c()
        }
        self.addObserver(self, forKeyPath: "text", options: [.new, .old], context: nil)
    }
    
    @objc func donePressed(){
        self.endEditing(true)
    }
}
