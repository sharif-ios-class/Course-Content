//
//  PredictVC.swift
//  NasehML
//
//  Created by ali on 1/30/19.
//  Copyright © 2019 pencode. All rights reserved.
//

import CoreML
import UIKit

class PredictVC: UIViewController {
    var titles : [String] = [
        "Lot (sq ft)",
        "Year Built",
        "Basement (sq ft)",
        "1st floor (sq ft)",
        "2nd floor (sq ft)",
        "Above ground (sq ft)",
        "FullBath number",
        "Bedrooms",
        "FirePlaces",
        "Garage (sq ft)",
        "Open porch (sq ft)",
        "Floor level",
    ]
    var fields : [TextField] = []
    let priceLabel = UILabel(text: "Price($) : 0", size: 15, color: .black, textAlignment: .center, backgroundColor: .white)
    override func viewDidLoad() {
        title = "Predict"
        view.backgroundColor = .white
        super.viewDidLoad()
        for title in titles {
            let field = TextField()
            field.title = title
            fields.append(field)
        }
        
        
        let mainStackView = UIStackView(distribution: .fillEqually, axis: .vertical, spacing: 10, views: [])
        let topLabel = UILabel(text: "Plaese fill in the blanks below,then click Predict!", size: 15, color: .black, textAlignment: .center, backgroundColor: .white)
        mainStackView.addArrangedSubview(topLabel)
        var rows : [UIStackView] = []
        for field in fields {
            if let last = rows.last , last.arrangedSubviews.count < 2 {
                last.addArrangedSubview(field)
            }else{
                let row = UIStackView(distribution: .fillEqually, axis: .horizontal, spacing: 10, views: [field])
                rows.append(row)
            }
        }
        
        for row in rows {
            mainStackView.addArrangedSubview(row)
        }
        
        
        let predictButton = UIButton(title: "Predict!", titleSize: 15, titleColor: .white, backgroundColor: .red, cornerRadius: 5, borderWidth: 0, borderColor: .clear)
        let clearButton = UIButton(title: "Clear", titleSize: 15, titleColor: .black, backgroundColor: UIColor.lightGray.withAlphaComponent(0.4), cornerRadius: 5, borderWidth: 0, borderColor: .clear)
        predictButton.addTarget(self, action: #selector(predict), for: .touchUpInside)
        let buttonStackView = UIStackView(distribution: .fillEqually, axis: .horizontal, spacing: 10, views: [predictButton,clearButton])
        clearButton.addTarget(self, action: #selector(clear), for: .touchUpInside)
        mainStackView.addArrangedSubview(buttonStackView)
        view.addSubview(mainStackView)
        mainStackView.snp.makeConstraints { (v) in
            v.edges.equalToSuperview().inset(10)
        }
        
        mainStackView.addArrangedSubview(priceLabel)
        
    
        
        
    }
    
    @objc func clear(){
        priceLabel.text =  "Price($) : 0"
        for field in fields {
            field.field.text = ""
            field.value = ""
        }
    }

    @objc func predict(){
        var features : [Double] = []
        for field in fields {
            features.append(Double(field.field.text!)!)
        }
        features[11] = features[2] + features[3] + features[4]
        let model = HousePrediction()
        do {
            let p = try model.prediction(_1stFlrSF: features[0], _2ndFlrSF: features[1], BedroomAbvGr: features[2], Fireplaces: features[3], FullBath: features[4], GarageArea: features[5], GrLivArea: features[6], LotArea: features[7], OpenPorchSF: features[8], TotalBsmtSF: features[9], YearBuilt: features[10], TotalSF: features[11]).SalePrice
            priceLabel.text = "Price($) : \(p)"
        }catch{
            fatalError("kose nane swift")
        }
    }
}
