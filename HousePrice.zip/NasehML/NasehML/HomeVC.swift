//
//  ViewController.swift
//  NasehML
//
//  Created by ali on 1/30/19.
//  Copyright © 2019 pencode. All rights reserved.
//

import UIKit
import SnapKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        

        
        
        title = "Home"
        super.viewDidLoad()
        let icon : UIImage = #imageLiteral(resourceName: "MainIcon")
        let iconImageView = UIImageView(image: icon)
        iconImageView.contentMode = .scaleAspectFit
        view.addSubview(iconImageView)
        iconImageView.snp.makeConstraints { (v) in
            v.center.equalToSuperview()
            v.width.equalToSuperview().multipliedBy(0.9)
            v.height.equalToSuperview().multipliedBy(0.6)
        }
        
        let predictButton = UIButton()
        predictButton.setTitle("Predict Your House's price!", for: .normal)
        predictButton.backgroundColor = .red
        predictButton.layer.cornerRadius = 5
        view.addSubview(predictButton)
        predictButton.snp.makeConstraints { (v) in
            v.width.equalToSuperview().multipliedBy(0.9)
            v.top.equalTo(iconImageView.snp.bottom).offset(20)
            v.height.equalTo(50)
            v.centerX.equalToSuperview()
        }
        
        predictButton.addTarget(self, action: #selector(predictPressed), for: .touchUpInside)
    }

    @objc func predictPressed(){
        navigationController?.pushViewController(PredictVC(), animated: true)
//        var features : [Double] = [8450,2003,856,856,854,1710,2,3,0,548,61,2566]
//        let w : [Double] = [ 3.41511689e-01 , 6.38824298e+02 , 1.08127983e+01 , 3.27825363e+00,8.72934825e+00 , 4.55414937e+01 , 3.91652235e+03 ,-1.17250326e+04,1.17860709e+04 , 5.58237615e+01 , 1.17537192e+01 , 2.28204002e+01]
//
//        let b : Double = -1234533.4565020867
//
//        print(dot(a: features, b: w) + b)
    }
    func dot(a : [Double],b:[Double]) -> Double {
        guard a.count == b.count else {
            fatalError("not equal")
        }
        
        var sum : Double = 0
        for i in 0..<a.count {
            sum += a[i] * b[i]
        }
        return sum
    }
}

