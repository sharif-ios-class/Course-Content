//
//  TextField.swift
//  CopyResan
//
//  Created by ali on 11/23/18.
//  Copyright © 2018 pencode. All rights reserved.
//

import UIKit

class TextField: UIView {

    public let field = UITextField(placeholder: "", icon: nil, textSize: 14, textColor: .black, backgroundColor: .clear, cornerRadius: 0, borderWidth: 0, borderColor: .clear, keyboardType: .numberPad)
    public var title : String = "" {
        didSet{
            titleLabel.text = title
        }
    }
    
    public var hint : String = ""  {
        didSet{
            hintLabel.text = hint
        }
    }
    
    public var value : String = "" {
        didSet{
            field.text = value
            if value.count > 0 {
                let titleWidth = self.titleLabel.frame.width
                let scaleTransform = CGAffineTransform(scaleX: 0.7, y: 0.7)
                let moveTransform = CGAffineTransform(translationX: 0.15 * titleWidth, y: 0)
                self.titleLabel.transform = scaleTransform.concatenating(moveTransform)
                self.titleLabel.snp.remakeConstraints({ (v) in
                    v.left.equalToSuperview().inset(5)
                    v.centerY.equalTo(self.titleContainer.snp.centerY)
                })
                
                self.titleLabel.textColor = UIColor.red
                self.layoutIfNeeded()
                
                isPlaceHolderUp = true
            }else{
                movePlaceHolderDown()
            }
        }
    }
    
    private var titleLabel = UILabel(text: "", size: 20, color: .gray, textAlignment: .left)
    private var hintLabel = UILabel(text: "", size: 12, color: .gray, textAlignment: .left)
    private let deactivatedUnderLine = UIView()
    private let activatedUnderLine = UIView()
    private let underLineView = UIView()
    let titleContainer = UIView()
    
    private var active : Bool = false
    private var isPlaceHolderUp : Bool = false
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        let mainStackView = UIStackView()
        mainStackView.axis = .vertical
        addSubview(mainStackView)
        mainStackView.snp.makeConstraints { (v) in
            v.edges.equalToSuperview()
        }
        
        
        mainStackView.addArrangedSubview(titleContainer)
        titleContainer.setHeight(25)
        
        let fieldContainer = UIView()
        fieldContainer.addSubview(field)
        field.tintColor = UIColor.red
        field.snp.makeConstraints { (v) in
            v.edges.equalToSuperview().inset(5)
        }
        fieldContainer.setHeight(35)
        mainStackView.addArrangedSubview(fieldContainer)
        
        
        deactivatedUnderLine.backgroundColor = UIColor.lightGray
        activatedUnderLine.backgroundColor = UIColor.red
        
        underLineView.addSubview(deactivatedUnderLine)
        underLineView.addSubview(activatedUnderLine)
        deactivatedUnderLine.snp.makeConstraints { (v) in
            v.edges.equalToSuperview()
        }
        activatedUnderLine.snp.makeConstraints { (v) in
            v.top.equalToSuperview()
            v.bottom.equalToSuperview()
            v.left.equalToSuperview()
            v.right.equalTo(activatedUnderLine.snp.left)
        }
        underLineView.setHeight(1)
        mainStackView.addArrangedSubview(underLineView)
        
        field.addTarget(self, action: #selector(editingDidBegin(_:)), for: .editingDidBegin)
        field.addTarget(self, action: #selector(editingDidEnd(_:)), for: .editingDidEnd)
        field.addTarget(self, action: #selector(editingChanged(_:)), for: .editingChanged)
        
        backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (v) in
            v.bottom.equalTo(self.field.snp.bottom)
            v.left.equalToSuperview().inset(5)
        }
        titleLabel.textColor = UIColor.lightGray
        
        //layoutIfNeeded()
        layer.cornerRadius = 5
        clipsToBounds = true
        //layer.masksToBounds = true
        
        let hintView = hintLabel.embedInView(10, 10, 10, 10)
        mainStackView.addArrangedSubview(hintView)
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didTap))
        addGestureRecognizer(tapGesture)
    }
    
    @objc func didTap(){
        field.becomeFirstResponder()
    }
    
    @objc func editingDidBegin(_ textField : UITextField){
        active = true
        //animate underline
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.activatedUnderLine.snp.remakeConstraints({ (v) in
                v.top.equalToSuperview()
                v.bottom.equalToSuperview()
                v.right.equalToSuperview()
                v.left.equalToSuperview()
            })
            
            self.movePlaceHolderUp()

            self.underLineView.layoutIfNeeded()
        }, completion: nil)
    }
    
    
    

    @objc func editingDidEnd(_ textField : UITextField){
        active = false
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.activatedUnderLine.snp.remakeConstraints({ (v) in
                v.top.equalToSuperview()
                v.bottom.equalToSuperview()
                v.left.equalToSuperview()
                v.right.equalTo(self.activatedUnderLine.snp.left)
            })
            
            self.movePlaceHolderDown()
            
            self.underLineView.layoutIfNeeded()
        }, completion: nil)
        
    }
    
    @objc func editingChanged(_ textField : UITextField){
        if active {
            movePlaceHolderUp()
        }
    }
    
    
    
    func movePlaceHolderUp(){
        if !isPlaceHolderUp {
            isPlaceHolderUp = true
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
                let titleWidth = self.titleLabel.frame.width
                let scaleTransform = CGAffineTransform(scaleX: 0.7, y: 0.7)
                let moveTransform = CGAffineTransform(translationX: 0.15 * titleWidth, y: 0)
                self.titleLabel.transform = scaleTransform.concatenating(moveTransform)
                self.titleLabel.snp.remakeConstraints({ (v) in
                    v.left.equalToSuperview()
                    v.centerY.equalTo(self.titleContainer.snp.centerY)
                })
                
                self.titleLabel.textColor = UIColor.red
                self.layoutIfNeeded()
            })
        }
    }
    
    func movePlaceHolderDown(){
        if isPlaceHolderUp && self.field.text?.count == 0 {
            isPlaceHolderUp = false
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
                self.titleLabel.snp.remakeConstraints { (v) in
                    v.bottom.equalTo(self.field.snp.bottom)
                    v.left.equalToSuperview().inset(5)
                }
                //self.titleLabel.frame = self.placeHolderOriginalFrame
                self.titleLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
                self.titleLabel.textColor = UIColor.lightGray
                self.layoutIfNeeded()
            })
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}



